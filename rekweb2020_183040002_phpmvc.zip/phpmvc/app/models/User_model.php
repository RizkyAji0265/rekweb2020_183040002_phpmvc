<?php  

class User_model {
	private $nama = 'Mochamad Rizky Aji Pangestu';

	public function getUser()
	{
		return $this->nama;
	}
}